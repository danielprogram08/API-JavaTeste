package br.com.criandoapi.projeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
