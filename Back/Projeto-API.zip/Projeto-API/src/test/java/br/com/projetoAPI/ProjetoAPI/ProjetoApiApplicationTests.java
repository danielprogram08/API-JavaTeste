package br.com.projetoAPI.ProjetoAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
